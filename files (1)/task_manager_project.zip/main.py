# Import functions from task_manager.task_utils package
from task_manager.task_utils import (
    tasks,
    add_task,
    mark_task_as_complete,
    view_pending_tasks,
    calculate_progress,
)


# Define the main function
def main():
    while True:
        print("Task Management System")
        print("1. Add Task")
        print("2. Mark Task as Complete")
        print("3. View Pending Tasks")
        print("4. View Progress")
        print("5. Exit")
        choice = input("Enter your choice (1-5): ").strip()

        if choice == "1":
            title = input("Enter task title: ")
            description = input("Enter task description: ")
            due_date = input("Enter due date (YYYY-MM-DD): ")
            add_task(title, description, due_date)
        elif choice == "2":
            if not view_pending_tasks():
                continue
            number = input("Enter the number of the task to mark complete: ").strip()
            if number.isdigit():
                mark_task_as_complete(int(number) - 1)  # menu is 1-based, list is 0-based
            else:
                print("Error: Please enter a valid task number.")
        elif choice == "3":
            view_pending_tasks()
        elif choice == "4":
            print(f"Progress: {calculate_progress():.1f}% of tasks completed")
        elif choice == "5":
            print("Exiting the program...")
            break
        else:
            print("Invalid choice. Please try again.")
        print()


if __name__ == "__main__":
    main()
